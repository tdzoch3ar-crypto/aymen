# Secure Proxy App

## الخطوات
1. انسخ `.env.example` إلى `.env` وعدل القيم.
2. `npm install`
3. `npm start`
4. افتح `frontend.html` للتجربة.
