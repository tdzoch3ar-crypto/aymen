// server.js
require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const crypto = require('crypto');
const fs = require('fs');
const jwt = require('jsonwebtoken');
const fetch = require('node-fetch');

const app = express();
app.use(helmet());
app.use(express.json({ limit: '200kb' }));

const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || 'localhost';
const INITIAL_PASSWORD = process.env.INITIAL_PASSWORD || 'AyMenStrongPass123!';
const JWT_SECRET = process.env.JWT_SECRET || 'VERY_SECRET_JWT_KEY';
const API_SHARED_SECRET = process.env.API_SHARED_SECRET || 'API_SHARED_SECRET';
const CLIENT_KEY = process.env.CLIENT_KEY || 'a_client_key_forfrontend';
const LOG_KEY_B64 = process.env.LOG_ENCRYPTION_KEY_BASE64 || null;

if (!LOG_KEY_B64) {
  console.error("ERROR: env LOG_ENCRYPTION_KEY_BASE64 is required.");
  process.exit(1);
}
const LOG_KEY = Buffer.from(LOG_KEY_B64, 'base64');

function encryptLog(plaintext) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', LOG_KEY, iv);
  const encrypted = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return Buffer.concat([iv, tag, encrypted]).toString('base64');
}
function appendEncryptedLog(line) {
  const enc = encryptLog(line);
  fs.appendFileSync('logs.enc', enc + '\n', { encoding: 'utf8' });
}

function requireClientKey(req, res, next) {
  const key = req.headers['x-client-key'] || '';
  if (key !== CLIENT_KEY) return res.status(401).json({ error: 'Unauthorized (client key)' });
  next();
}

app.post('/auth', requireClientKey, (req, res) => {
  const password = (req.body && req.body.password) || '';
  if (password === INITIAL_PASSWORD) {
    const token = jwt.sign({ sub: 'web-client' }, JWT_SECRET, { expiresIn: '15m' });
    appendEncryptedLog(`[LOGIN] SUCCESS`);
    return res.json({ ok: true, token, expiresInSec: 900 });
  } else {
    appendEncryptedLog(`[LOGIN] FAIL`);
    return res.status(401).json({ ok: false, error: 'Invalid password' });
  }
});

function requireJwt(req, res, next) {
  const h = req.headers['authorization'] || '';
  if (!h.startsWith('Bearer ')) return res.status(401).json({ error: 'Missing token' });
  try {
    req.user = jwt.verify(h.slice(7), JWT_SECRET);
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Invalid token' });
  }
}

function signHmac(secret, data) {
  return crypto.createHmac('sha256', secret).update(data).digest('hex');
}

app.post('/proxy/send-items', requireClientKey, requireJwt, async (req, res) => {
  const body = req.body || {};
  const access = body.access || '';
  const items = Array.isArray(body.items) ? body.items : [];
  const ts = Date.now().toString();
  const bodyHash = crypto.createHash('sha256').update(JSON.stringify({access,items})).digest('hex');
  const canonical = `POST\n/proxy/send-items\n${ts}\n${bodyHash}`;
  const signature = signHmac(API_SHARED_SECRET, canonical);
  let apiUrl = `https://gpl-items-v3.vercel.app/get?access=${encodeURIComponent(access)}`;
  items.forEach(it => { apiUrl += `&itemid=${encodeURIComponent(it)}`; });
  try {
    const resp = await fetch(apiUrl, { headers: { 'X-Timestamp': ts, 'X-Signature': signature } });
    const text = await resp.text();
    appendEncryptedLog(`[SEND-ITEMS] count=${items.length}`);
    res.status(resp.status).send(text);
  } catch (e) {
    appendEncryptedLog(`[SEND-ITEMS-ERR] ${e.message}`);
    res.status(500).json({ error: 'proxy error' });
  }
});

app.post('/proxy/send-bio', requireClientKey, requireJwt, async (req, res) => {
  const body = req.body || {};
  const access = body.access || '';
  const textBio = body.text || '';
  const ts = Date.now().toString();
  const bodyHash = crypto.createHash('sha256').update(JSON.stringify({access,text:textBio})).digest('hex');
  const canonical = `POST\n/proxy/send-bio\n${ts}\n${bodyHash}`;
  const signature = signHmac(API_SHARED_SECRET, canonical);
  const apiUrl = `https://gpl-bio.vercel.app/get?access=${encodeURIComponent(access)}&text=${encodeURIComponent(textBio)}`;
  try {
    const resp = await fetch(apiUrl, { headers: { 'X-Timestamp': ts, 'X-Signature': signature } });
    const text = await resp.text();
    appendEncryptedLog(`[SEND-BIO] len=${textBio.length}`);
    res.status(resp.status).send(text);
  } catch (e) {
    appendEncryptedLog(`[SEND-BIO-ERR] ${e.message}`);
    res.status(500).json({ error: 'proxy error' });
  }
});

app.get('/health', (req, res) => res.json({ ok: true }));
app.listen(PORT, () => console.log(`Secure proxy running on http://${HOST}:${PORT}`));