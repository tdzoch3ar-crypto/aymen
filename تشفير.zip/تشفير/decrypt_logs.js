require('dotenv').config();
const fs = require('fs');
const crypto = require('crypto');

const LOG_KEY_B64 = process.env.LOG_ENCRYPTION_KEY_BASE64;
if (!LOG_KEY_B64) { console.error("Set LOG_ENCRYPTION_KEY_BASE64 in .env"); process.exit(1); }
const KEY = Buffer.from(LOG_KEY_B64, 'base64');

function decryptLine(b64line) {
  try {
    const buf = Buffer.from(b64line, 'base64');
    const iv = buf.slice(0,12);
    const tag = buf.slice(12,28);
    const encrypted = buf.slice(28);
    const decipher = crypto.createDecipheriv('aes-256-gcm', KEY, iv);
    decipher.setAuthTag(tag);
    return Buffer.concat([decipher.update(encrypted), decipher.final()]).toString('utf8');
  } catch (e) {
    return `[ERR] ${e.message}`;
  }
}
if (!fs.existsSync('logs.enc')) { console.error("logs.enc not found"); process.exit(1); }
fs.readFileSync('logs.enc','utf8').split(/\r?\n/).filter(Boolean).forEach((L,i)=>{
  console.log(`${i+1}: ${decryptLine(L)}`);
});